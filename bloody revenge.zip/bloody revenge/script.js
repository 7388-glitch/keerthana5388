/* =========================================================
   BLOODY REVENGE
   COMIC BOOK
========================================================= */


/* =========================================================
   CHARACTER IMAGES
========================================================= */

const characters = {

    LEON: "images/leon.jpg",

    ALEX: "images/alex.jpg",

    HANNAH: "images/hannah.jpg",

    MACK: "images/mack.jpg",

    NOVA: "images/nova.jpg",

    BOSS: "images/boss.jpg",

    RAYAN: "images/rayan.jpg",

    MAN: "images/man.jpg"

};


/* =========================================================
   CHAPTER DATA
========================================================= */

const chapters = [

    /* =====================================================
       COVER
    ===================================================== */

    {
        title: "BLOODY REVENGE",

        cover: true,

        panels: [

            {
                image: "images/cover.jpg",

                caption:
                    "A mystery • crime • psychological thriller",

                dialogues: [
                    {
                        speaker: "",
                        text:
                            "Five friends. A hidden truth. A powerful enemy. And a revenge that will change everything."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 1
    ===================================================== */

    {
        title: "Chapter 1 — The Beginning",

        panels: [

            {
                image: "images/abandoned-building.jpg",

                caption:
                    "INT. OLD ABANDONED BUILDING — NIGHT\n\n8:00 PM",

                dialogues: [

                    {
                        speaker: "UNKNOWN MAN",
                        text: "LET ME OUT! LET ME OUT!"
                    },

                    {
                        speaker: "Narration",
                        text:
                            "A respectable-looking man is locked inside an old abandoned building. He screams for help, but nobody comes."
                    }

                ]
            },


            {
                image: "images/man.jpg",

                caption:
                    "After shouting for a long time, the man finally becomes silent and sits in a corner.",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Footsteps slowly approach the room."
                    },

                    {
                        speaker: "Man",
                        text:
                            "Who's there?"
                    }

                ]
            },


            {
                image: "images/abandoned-building.jpg",

                caption:
                    "The locked door opens.",

                dialogues: [

                    {
                        speaker: "Stranger 1",
                        text:
                            "Oh... you're awake?"
                    },

                    {
                        speaker: "Man",
                        text:
                            "Why have you locked me here? Let me out!"
                    }

                ]
            },


            {
                image: "images/basement.jpg",

                dialogues: [

                    {
                        speaker: "Stranger 2",
                        text:
                            "You should have thought about that before."
                    },

                    {
                        speaker: "Man",
                        text:
                            "What do you want from me?"
                    },

                    {
                        speaker: "Narration",
                        text:
                            "The strangers remain silent."
                    }

                ]
            },


            {
                image: "images/abandoned-building.jpg",

                dialogues: [

                    {
                        speaker: "Stranger 1",
                        text:
                            "There is no way out."
                    },

                    {
                        speaker: "Narration",
                        text:
                            "The door closes again. The room falls silent."
                    }

                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 2
    ===================================================== */

    {
        title: "Chapter 2 — The Four Friends",

        panels: [

            {
                image: "images/leon-house.jpg",

                caption:
                    "INT. LEON'S HOUSE — MORNING",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Leon, Alex, Hannah and Mack are four close friends who have known each other for years."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "Come on, guys. We need to get out today!"
                    }
                ]
            },


            {
                image: "images/alex.jpg",

                dialogues: [

                    {
                        speaker: "Alex",
                        text:
                            "You all look like you're attending a funeral."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "That's because you're the only one who thinks everything is funny."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "Exactly!"
                    }

                ]
            },


            {
                image: "images/hannah.jpg",

                dialogues: [

                    {
                        speaker: "Hannah",
                        text:
                            "You two never stop arguing."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "That's why we're friends."
                    }
                ]
            },


            {
                image: "images/leon.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Leon is the quiet and responsible one. Alex is an entertaining boxer. Hannah is calm and observant. Mack is practical and intelligent."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "Whatever happens, we stay together."
                    }

                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 3
    ===================================================== */

    {
        title: "Chapter 3 — The News",

        panels: [

            {
                image: "images/company-office.jpg",

                caption:
                    "A normal day suddenly becomes something else.",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The friends hear shocking news about a powerful businessman and his company."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "Did you hear what happened?"
                    }
                ]
            },


            {
                image: "images/leon.jpg",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "What happened?"
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "Someone connected to the company has disappeared."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "Again?"
                    }

                ]
            },


            {
                image: "images/boss.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The name of the company boss begins appearing everywhere."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "Something about this doesn't feel right."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "Then we need to find out the truth."
                    }

                ]
            },


            {
                image: "images/company-office.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Unknown to the friends, someone is already watching them."
                    },

                    {
                        speaker: "Unknown Voice",
                        text:
                            "They are getting too close."
                    }

                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 4
    ===================================================== */

    {
        title: "Chapter 4 — The Hidden House",

        panels: [

            {
                image: "images/hidden-house.jpg",

                caption:
                    "INT. HIDDEN HOUSE — NIGHT",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The friends discover a hidden house connected to the mysterious events."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "This place gives me serious bad vibes."
                    }
                ]
            },


            {
                image: "images/basement.jpg",

                dialogues: [

                    {
                        speaker: "Mack",
                        text:
                            "Look at this."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "Photos..."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "And every one of them is connected to the company."
                    }

                ]
            },


            {
                image: "images/basement.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The room contains photographs, documents and clues."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "So this wasn't random."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "No. Someone planned all of this."
                    }

                ]
            },


            {
                image: "images/hidden-house.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Suddenly, they hear a sound from another room."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "Did you hear that?"
                    },

                    {
                        speaker: "Mack",
                        text:
                            "We're not alone."
                    }

                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 5
    ===================================================== */

    {
        title: "Chapter 5 — The Boss's Son",

        panels: [

            {
                image: "images/company-office.jpg",

                caption:
                    "THE COMPANY BOSS'S SON IS REVEALED.",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The investigation leads the friends to an unexpected person — the boss's son."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "You knew about all of this."
                    }
                ]
            },


            {
                image: "images/boss.jpg",

                dialogues: [

                    {
                        speaker: "Boss's Son",
                        text:
                            "You have no idea what you've stepped into."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "That's a pretty dramatic way of saying hello."
                    }
                ]
            },


            {
                image: "images/company-office.jpg",

                dialogues: [

                    {
                        speaker: "Hannah",
                        text:
                            "Why are people disappearing?"
                    },

                    {
                        speaker: "Boss's Son",
                        text:
                            "Some questions are better left unanswered."
                    }
                ]
            },


            {
                image: "images/leon.jpg",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "We're not leaving until we know the truth."
                    },

                    {
                        speaker: "Narration",
                        text:
                            "The friends have unknowingly placed themselves in danger."
                    }

                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 6
    ===================================================== */

    {
        title: "Chapter 6 — The Next Target",

        panels: [

            {
                image: "images/leon-house.jpg",

                caption:
                    "INT. LEON'S HOUSE — NIGHT",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "We found enough evidence to know something is happening."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "But we still don't know who's behind it."
                    }
                ]
            },


            {
                image: "images/alex.jpg",

                dialogues: [

                    {
                        speaker: "Alex",
                        text:
                            "Wait... where is Hannah?"
                    },

                    {
                        speaker: "Leon",
                        text:
                            "She was just here."
                    }
                ]
            },


            {
                image: "images/hidden-house.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "A message appears. Someone has identified the group's next target."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "Guys... this is about one of us."
                    }
                ]
            },


            {
                image: "images/leon.jpg",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "Nobody goes anywhere alone."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "Agreed."
                    }

                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 7
    ===================================================== */

    {
        title: "Chapter 7 — The Message",

        panels: [

            {
                image: "images/leon-house.jpg",

                caption:
                    "A mysterious message arrives.",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The message contains information only someone close to them could know."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "How could they know this?"
                    }
                ]
            },


            {
                image: "images/nova.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "Because the person behind this has been watching you."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "Who are you?"
                    }
                ]
            },


            {
                image: "images/nova.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "Someone who knows the truth."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "That's not suspicious at all."
                    }
                ]
            },


            {
                image: "images/hidden-house.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Nova becomes connected to the mystery, but her real purpose remains unclear."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 8
    ===================================================== */

    {
        title: "Chapter 8 — The Next Target",

        panels: [

            {
                image: "images/police-station.jpg",

                caption:
                    "POLICE STATION",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "We need help."
                    },

                    {
                        speaker: "Officer",
                        text:
                            "Do you have evidence?"
                    }
                ]
            },


            {
                image: "images/police-station.jpg",

                dialogues: [

                    {
                        speaker: "Mack",
                        text:
                            "We have photographs, messages and documents."
                    },

                    {
                        speaker: "Officer",
                        text:
                            "Then bring everything you have."
                    }
                ]
            },


            {
                image: "images/forest-road.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "Meanwhile, someone is moving toward the next target."
                    },

                    {
                        speaker: "Unknown Voice",
                        text:
                            "One more."
                    }
                ]
            },


            {
                image: "images/forest-road.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The friends realize that time is running out."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "We have to get there first."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 9
    ===================================================== */

    {
        title: "Chapter 9 — The Final Target",

        panels: [

            {
                image: "images/leon-house.jpg",

                caption:
                    "INT. LEON'S HOUSE — MORNING",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "There is only one photo left."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "Then that person is the final target."
                    }
                ]
            },


            {
                image: "images/nova.jpg",

                dialogues: [

                    {
                        speaker: "Hannah",
                        text:
                            "Who is it?"
                    },

                    {
                        speaker: "Leon",
                        text:
                            "Nova."
                    }
                ]
            },


            {
                image: "images/company-office.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The clues point back to the company's main boss."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "So the whole thing comes back to him."
                    }
                ]
            },


            {
                image: "images/forest-road.jpg",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "We have to find Nova before they do."
                    },

                    {
                        speaker: "Narration",
                        text:
                            "The friends leave for another city."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 10
    ===================================================== */

    {
        title: "Chapter 10 — The Final Target",

        panels: [

            {
                image: "images/forest-road.jpg",

                caption:
                    "THE FRIENDS ARRIVE IN ANOTHER CITY.",

                dialogues: [

                    {
                        speaker: "Alex",
                        text:
                            "This trip keeps getting worse."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "Focus, Alex."
                    }
                ]
            },


            {
                image: "images/nova.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "You shouldn't have come here."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "We came because you're in danger."
                    }
                ]
            },


            {
                image: "images/company-office.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The truth about the boss, his son and the hidden operation begins to come together."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "This was never about random victims."
                    }
                ]
            },


            {
                image: "images/hidden-house.jpg",

                dialogues: [

                    {
                        speaker: "Mack",
                        text:
                            "They were all connected."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "And Nova was the final piece."
                    }
                ]
            },


            {
                image: "images/abandoned-building.jpg",

                dialogues: [

                    {
                        speaker: "Unknown Voice",
                        text:
                            "You should have stayed away."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "We're not afraid of you."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 11
    ===================================================== */

    {
        title: "Chapter 11 — What Happened to Nova",

        panels: [

            {
                image: "images/nova.jpg",

                caption:
                    "NOVA'S STORY",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "I knew they would come for me eventually."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "Tell us everything."
                    }
                ]
            },


            {
                image: "images/nova.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "The company wasn't what everyone believed it was."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "And the boss?"
                    }
                ]
            },


            {
                image: "images/boss.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "He knew everything."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "Then why did nobody expose him?"
                    }
                ]
            },


            {
                image: "images/abandoned-building.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "Because everyone who tried disappeared."
                    },

                    {
                        speaker: "Narration",
                        text:
                            "The truth is finally beginning to emerge."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 12
    ===================================================== */

    {
        title: "Chapter 12 — The Truth Comes Out",

        panels: [

            {
                image: "images/police-station.jpg",

                caption:
                    "THE EVIDENCE IS HANDED OVER.",

                dialogues: [

                    {
                        speaker: "Leon",
                        text:
                            "This is everything we found."
                    },

                    {
                        speaker: "Officer",
                        text:
                            "This could expose the entire operation."
                    }
                ]
            },


            {
                image: "images/company-office.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The evidence connects the hidden house, the company and the people who disappeared."
                    },

                    {
                        speaker: "Hannah",
                        text:
                            "Now everyone will know the truth."
                    }
                ]
            },


            {
                image: "images/boss.jpg",

                dialogues: [

                    {
                        speaker: "Boss",
                        text:
                            "You think this is over?"
                    },

                    {
                        speaker: "Leon",
                        text:
                            "It's over for you."
                    }
                ]
            },


            {
                image: "images/police-station.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The truth finally reaches the authorities."
                    },

                    {
                        speaker: "Alex",
                        text:
                            "We actually did it."
                    }
                ]
            }

        ]
    },


    /* =====================================================
       CHAPTER 13
    ===================================================== */

    {
        title: "Chapter 13 — Nova's Final Goodbye",

        panels: [

            {
                image: "images/cemetery.jpg",

                caption:
                    "CEMETERY — EVENING",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "After everything that happened, the friends gather one final time."
                    }
                ]
            },


            {
                image: "images/nova.jpg",

                dialogues: [

                    {
                        speaker: "Nova",
                        text:
                            "Thank you for believing me."
                    },

                    {
                        speaker: "Leon",
                        text:
                            "You don't have to thank us."
                    }
                ]
            },


            {
                image: "images/cemetery.jpg",

                dialogues: [

                    {
                        speaker: "Hannah",
                        text:
                            "Some stories stay with us forever."
                    },

                    {
                        speaker: "Mack",
                        text:
                            "But at least the truth is finally out."
                    }
                ]
            },


            {
                image: "images/cemetery.jpg",

                dialogues: [

                    {
                        speaker: "Narration",
                        text:
                            "The friends walk away together as the sun disappears behind the cemetery."
                    },

                    {
                        speaker: "Narration",
                        text:
                            "THE END."
                    }
                ]
            }

        ]
    }

];


/* =========================================================
   CURRENT POSITION
========================================================= */

let currentChapter = 0;

let currentPanel = 0;


/* =========================================================
   ELEMENTS
========================================================= */

const chapterMenu =
    document.getElementById("chapterMenu");

const chapterTitle =
    document.getElementById("chapterTitle");

const comicPanel =
    document.getElementById("comicPanel");

const pageNumber =
    document.getElementById("pageNumber");

const previousButton =
    document.getElementById("previousButton");

const nextButton =
    document.getElementById("nextButton");


/* =========================================================
   CREATE CHAPTER BUTTONS
========================================================= */

function createChapterMenu() {

    chapterMenu.innerHTML = "";

    chapters.forEach((chapter, index) => {

        const button =
            document.createElement("button");

        button.className = "chapter-button";

        button.textContent =
            index === 0
                ? "COVER"
                : "CH " + index;

        button.onclick = function () {

            openChapter(index);

        };

        chapterMenu.appendChild(button);

    });

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(text) {

    return text

        .replace(/&/g, "&amp;")

        .replace(/</g, "&lt;")

        .replace(/>/g, "&gt;")

        .replace(/"/g, "&quot;")

        .replace(/'/g, "&#039;");

}


/* =========================================================
   DISPLAY PANEL
========================================================= */

function displayPanel() {

    const chapter =
        chapters[currentChapter];

    const panel =
        chapter.panels[currentPanel];


    chapterTitle.textContent =
        chapter.title;


    /* =========================
       COVER
    ========================= */

    if (chapter.cover) {

        comicPanel.innerHTML = `

            <div class="cover-panel">

                <img
                    src="${panel.image}"
                    class="cover-image"
                    onerror="this.style.display='none'"
                >

                <div class="cover-content">

                    <div class="cover-title">
                        BLOODY REVENGE
                    </div>

                    <div class="cover-subtitle">
                        A Mystery • Crime • Psychological Thriller
                    </div>

                </div>

            </div>
        `;

    }

    else {

        let html = `

            <div class="panel-image-container">

                <img
                    src="${panel.image}"
                    class="panel-image"
                    onerror="
                        this.style.display='none';
                        this.parentElement.innerHTML='<div class=image-missing>🖼️ Image not found<br>Check the image name in the images folder.</div>';
                    "
                >

            </div>

            <div class="panel-content">
        `;


        /* CAPTION */

        if (panel.caption) {

            html += `

                <div class="caption">

                    ${escapeHTML(panel.caption)
                        .replace(/\n/g, "<br>")}

                </div>

            `;

        }


        /* DIALOGUES */

        if (panel.dialogues) {

            panel.dialogues.forEach(dialogue => {

                if (dialogue.speaker === "Narration") {

                    html += `

                        <div class="narration">

                            ${escapeHTML(dialogue.text)}

                        </div>

                    `;

                }

                else {

                    const avatar =
                        characters[dialogue.speaker.toUpperCase()]
                        || "images/man.jpg";


                    html += `

                        <div class="dialogue">

                            <img
                                src="${avatar}"
                                class="character-image"
                                onerror="this.style.visibility='hidden'"
                            >

                            <div class="speech">

                                <span class="speaker">

                                    ${escapeHTML(dialogue.speaker)}

                                </span>

                                ${escapeHTML(dialogue.text)}

                            </div>

                        </div>

                    `;

                }

            });

        }


        html += `</div>`;

        comicPanel.innerHTML = html;

    }


    /* PAGE NUMBER */

    pageNumber.textContent =
        `Chapter ${currentChapter} / ${chapters.length - 1}
        •
        Panel ${currentPanel + 1} / ${chapter.panels.length}`;


    /* BUTTONS */

    previousButton.disabled =
        currentChapter === 0 &&
        currentPanel === 0;


    nextButton.disabled =
        currentChapter === chapters.length - 1 &&
        currentPanel === chapter.panels.length - 1;


    /* ACTIVE CHAPTER */

    const buttons =
        document.querySelectorAll(".chapter-button");

    buttons.forEach((button, index) => {

        button.classList.toggle(
            "active",
            index === currentChapter
        );

    });

}


/* =========================================================
   NEXT PANEL
========================================================= */

function nextPanel() {

    const chapter =
        chapters[currentChapter];


    if (currentPanel < chapter.panels.length - 1) {

        currentPanel++;

        displayPanel();

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }

    else if (currentChapter < chapters.length - 1) {

        currentChapter++;

        currentPanel = 0;

        displayPanel();

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }

}


/* =========================================================
   PREVIOUS PANEL
========================================================= */

function previousPanel() {

    if (currentPanel > 0) {

        currentPanel--;

        displayPanel();

    }

    else if (currentChapter > 0) {

        currentChapter--;

        currentPanel =
            chapters[currentChapter].panels.length - 1;

        displayPanel();

    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================================================
   OPEN CHAPTER
========================================================= */

function openChapter(index) {

    currentChapter = index;

    currentPanel = 0;

    displayPanel();

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================================================
   GO TO COVER
========================================================= */

function goHome() {

    currentChapter = 0;

    currentPanel = 0;

    displayPanel();

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================================================
   KEYBOARD CONTROLS
========================================================= */

document.addEventListener(
    "keydown",
    function(event) {

        if (event.key === "ArrowRight") {

            nextPanel();

        }

        if (event.key === "ArrowLeft") {

            previousPanel();

        }

    }
);


/* =========================================================
   START COMIC
========================================================= */

createChapterMenu();

displayPanel();